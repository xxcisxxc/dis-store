#ifndef CLIENT_H_
#define CLIENT_H_

int run_client ();

#endif /* client.h */
