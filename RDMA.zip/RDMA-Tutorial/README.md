# RDMA-Tutorial
This project presents an example based tutorial on RDMA based programming. A more detailed 
discussion can be found in the Wiki page.

## Hardware and software discussion
 * Mellanox HCAs
 * GNU make
 * gcc-4.4
 * Mellanox OFED 3.3

## How the build project
Simply use ```make``` to build the release version or ```make debug``` to build the 
debug version.
 
## Code structure

## Contact

Jiachen Xue (xuejiachen@gmail.com)
